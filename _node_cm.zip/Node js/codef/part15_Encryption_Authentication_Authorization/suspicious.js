   var str = 'My name is ' + name + ' from ' + domain;
   console.log(str):
