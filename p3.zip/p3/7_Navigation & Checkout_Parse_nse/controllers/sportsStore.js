﻿angular.module("sportsStore")
    .constant("dataUrl","https://api.parse.com/1/classes/products")

    .run(function($http){

        $http.defaults.headers.common["X-Parse-Application-Id"]
        ="y9rIGKz3LOkyhmvBEo8P0VMQyHTRy3lnVcGhzrjk";

         $http.defaults.headers.common["X-Parse-REST-API-Key"]
        ="jjYumimlfd6vgagaEpEzhktPuUsVOueuIx5MuhLa";

    }

        )

    .controller("sportsStoreCtrl",function($scope,$http,dataUrl)

     {

        $scope.data = {};

        $http.get(dataUrl)
            .success(function (data) {
                $scope.data.products = data.results;
            })
            .error(function (error) {
                $scope.data.error = response.error || response;
                console.log("error");
            });
    });
