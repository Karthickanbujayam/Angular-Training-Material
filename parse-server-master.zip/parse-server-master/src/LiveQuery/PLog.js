import { addGroup } from '../logger';

let PLog = addGroup('parse-live-query-server');

module.exports = PLog;
