module.exports = function(options) {
  return {
    options: options
  };
};
