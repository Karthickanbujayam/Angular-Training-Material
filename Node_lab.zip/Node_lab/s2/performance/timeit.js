console.time('timer');
setTimeout(function(){
   console.timeEnd('timer');
},1000)

