(function foo() {
    console.log('foo was executed!');
})();
