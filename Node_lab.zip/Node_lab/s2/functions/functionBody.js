function functionName() {
    // function body
    // optional return;
}
