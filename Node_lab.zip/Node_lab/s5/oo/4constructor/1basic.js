function Foo() { }

console.log(Foo.prototype.constructor === Foo); // true