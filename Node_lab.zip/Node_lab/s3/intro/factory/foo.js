module.exports = function () {
    return {
        something: 123
    };
};