setTimeout(function () {
    console.log('timeout completed');
}, 1000);