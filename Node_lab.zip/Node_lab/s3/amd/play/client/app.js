define(['./foo', './bar'], function (foo, bar) {
    foo();
    bar.log();
});