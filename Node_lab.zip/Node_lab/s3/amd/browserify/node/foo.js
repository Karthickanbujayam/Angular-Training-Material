module.exports = function () {
    console.log('foo was called');
}