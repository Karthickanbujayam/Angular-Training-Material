exports.log = function () {
    console.log('bar.log was called');
}