var os = require('os');
console.log('This machine has', os.cpus().length, 'CPUs');