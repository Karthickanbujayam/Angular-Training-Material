window.onload = function () {
    document.body.innerHTML += '<strong>Talk JavaScript with me</strong>';
}