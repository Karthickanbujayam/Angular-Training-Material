var _ = require('underscore');
console.log(_.min([3, 1, 2])); // 1