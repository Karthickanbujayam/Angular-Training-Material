module.exports = function () {
    console.log('bar2 was called');
}
