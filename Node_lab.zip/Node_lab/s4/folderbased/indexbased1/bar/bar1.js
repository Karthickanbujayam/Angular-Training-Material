module.exports = function () {
    console.log('bar1 was called');
}
